package org.intelligentriver.front.model.metadata;

import org.intelligentriver.front.model.IDbJson;

public class SensingDeviceBrief extends IDbJson {

    public String id;
    public String label;
    public String type;
    public String[] params;
}
