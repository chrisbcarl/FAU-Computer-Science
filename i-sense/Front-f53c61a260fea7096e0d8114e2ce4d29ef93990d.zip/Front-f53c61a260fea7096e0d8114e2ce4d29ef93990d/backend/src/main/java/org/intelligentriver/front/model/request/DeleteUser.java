package org.intelligentriver.front.model.request;

public class DeleteUser extends ITokenRequest {

    public String id;
}
