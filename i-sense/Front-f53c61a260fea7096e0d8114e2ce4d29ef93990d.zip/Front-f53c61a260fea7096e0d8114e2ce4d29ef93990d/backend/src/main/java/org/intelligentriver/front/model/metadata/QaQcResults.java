package org.intelligentriver.front.model.metadata;

import org.intelligentriver.front.model.IDbJson;

public class QaQcResults extends IDbJson {

    public String check;
    public String label;
    public String message;
    public boolean status = false;
}
