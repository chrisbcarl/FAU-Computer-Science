package org.intelligentriver.front.model.request;

public class PostSignOut {

    public String login;
    public String token;
}
