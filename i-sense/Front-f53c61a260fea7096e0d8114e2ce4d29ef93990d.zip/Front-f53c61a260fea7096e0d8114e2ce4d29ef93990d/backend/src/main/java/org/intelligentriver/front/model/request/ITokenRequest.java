package org.intelligentriver.front.model.request;

public class ITokenRequest {

    public String token;
}
