export interface CustomRoute {
  currentRoute: string;
  currentResource: string;
  currentParams: {};
  currentPath: string[];
}
