package org.intelligentriver.front.model.metadata;

import org.intelligentriver.front.model.IDbJson;

public class RadioProperty extends IDbJson {

    public String label;
    public String name;
    public String type;
    public boolean required;
}
