package org.intelligentriver.front.model.request;

public class DeleteNotificationSubscription extends ITokenRequest {

    public String id;
}
