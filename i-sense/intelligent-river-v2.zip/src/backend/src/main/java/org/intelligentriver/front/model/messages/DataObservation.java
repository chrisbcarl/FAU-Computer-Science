package org.intelligentriver.front.model.messages;

public class DataObservation extends Observation {
	
	public double[] readings;
}