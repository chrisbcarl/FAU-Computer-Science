package org.intelligentriver.front.model;

import org.intelligentriver.front.model.metadata.Project;

import java.util.List;

public class Caching {

    public List<Project> projects;
}
