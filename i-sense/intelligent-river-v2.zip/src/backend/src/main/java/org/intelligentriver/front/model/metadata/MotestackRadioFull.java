package org.intelligentriver.front.model.metadata;

import org.intelligentriver.front.model.IDbJson;

import java.util.HashMap;

public class MotestackRadioFull extends IDbJson {

    public Radio radio;
    public HashMap<String, String> config;
}
