package org.intelligentriver.front.model.request;

public class DeleteMaintenance extends ITokenRequest {

    public String maintenanceId;
}
