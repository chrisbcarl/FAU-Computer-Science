package org.intelligentriver.front.model.request;

public class UpdateUser extends ITokenRequest {

    public String id;
    public String email;
    public String username;
}
