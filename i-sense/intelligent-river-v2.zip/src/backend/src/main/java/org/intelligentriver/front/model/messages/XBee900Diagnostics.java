package org.intelligentriver.front.model.messages;

public class XBee900Diagnostics {
	
	public Long wakeErrors;
	public Long cmdErrors;
	public Long sendErrors;
	public Long frameErrors;
	public Long baseRSSI;
	public Long cumulativeUp;
}