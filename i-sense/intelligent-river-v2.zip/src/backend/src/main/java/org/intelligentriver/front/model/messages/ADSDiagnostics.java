package org.intelligentriver.front.model.messages;

public class ADSDiagnostics {
	
	public Long wakeErrors;
	public Long configErrors;
	public Long conversionErrors;
	public Long sampleErrors;
	public Long cumulativeUp;
}