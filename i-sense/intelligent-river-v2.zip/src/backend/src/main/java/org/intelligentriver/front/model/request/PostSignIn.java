package org.intelligentriver.front.model.request;

public class PostSignIn {

    public String login;
    public String passwordSHA1;
}
