package org.intelligentriver.front.model.metadata;

import org.intelligentriver.front.model.IDbJson;

import java.util.HashMap;

public class MotestackRadioBrief extends IDbJson {

    public String radioId;
    public HashMap<String, String> config;
}
