package org.intelligentriver.front.model.messages;

public class OneWireDiagnostics {
	
	public Long searchErrors;
	public Long conversionErrors;
	public Long collectionErrors;
	public Long cumulativeUp;
}
