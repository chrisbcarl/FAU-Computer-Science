package org.intelligentriver.front.model.messages;

public class SDI12Diagnostics {

	public Long activationErrors;
	public Long conversionErrors;
	public Long collectionErrors;
	public Long cumulativeUp;
}
