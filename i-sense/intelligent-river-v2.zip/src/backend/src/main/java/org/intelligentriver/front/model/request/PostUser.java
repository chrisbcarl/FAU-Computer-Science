package org.intelligentriver.front.model.request;

public class PostUser extends ITokenRequest {

    public String email;
    public String username;
    public String passwordSHA1;
}
