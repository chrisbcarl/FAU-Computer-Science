// nothing to change really

export interface Statistics {
  data?: {
    date?: string;
    records?: string;
    samples?: string;
  };
  diagnostics?: {
    date?: string;
    records?: string;
    samples?: string;
  };
}
