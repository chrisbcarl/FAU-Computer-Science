import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-deployments',
  templateUrl: './deployments.component.html',
  styleUrls: ['./deployments.component.scss']
})
export class DeploymentsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
