// inclass2.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include<iostream>
using namespace std;

class Point
{
public:
	int x;
	int y;
	void setz(int z)
	{
	  this->z=z;
	  //(*this).z=z; an equivalent way
	}
	void printz(){cout<<z<<endl;}
	double norm();
	Point() {
		cout<<"First Constructor"<<endl;
	}
	Point(int x){
	this->x = x;
		cout<<"Second Constructor "<< x<<endl;
	}
	Point(int x, int y){
		this->x =x;
		this->y =y;
		cout<<"Third Constructor "<< x<<endl;
	}
	~Point(){cout<<"destructor "<< x <<endl;}

	friend void test2(Point x);
private:
	int z;
};

double Point::norm()
{
  return sqrt(x*x + y*y + z*z);
}

void test()
{
	cout<<"begin of function"<<endl<<endl;
	Point a(5);
	Point *ptr;
	ptr = new Point(6,3);
	
}

void test2(Point x)
{
	cout<<x.z<<endl;
}
int _tmain(int argc, _TCHAR* argv[])
{	
	Point a(1),b(2,3),c(3);
	
	a.setz(10);
	a.printz();
	test2(a);
	Point *ptr;
	ptr = new Point(4,4);
	delete ptr;
 cout<<endl<<endl<<endl;

 test();
 cout<<"end of test abc"<<endl;
    ptr= new Point(7);
	return 0;
}

