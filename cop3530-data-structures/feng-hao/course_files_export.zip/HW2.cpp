

#include <iostream>
using namespace std;



class Mat22
{
    //the class for 2 by 2 matrices
public:
    
    Mat22(); // default constructor
    
    Mat22(int a,int b, int c, int d); // set the matrix as  the input
    Mat22(const Mat22 &b); // copy constructor
    
    
    void operator=(const Mat22 &b); // assignment operator
    Mat22 operator+(const Mat22 &b);// add two matrices
    Mat22 operator-(const Mat22 &b);// similar as above
    Mat22 operator*(const Mat22 &b);// matrix multiplication
 
    Mat22 fastexp(int n);// compute matrix to the power of n
    void display(ostream &out);// print the matrix, whatever way you like as long as it makes sense
    void input(ifstream &in)//use in to get user input for the matrix
    
private:
    
    int a,b,c,d;// store matrix  [a,b]
                //               [c,d]
    
    
};


//implement operator<< and operator>> so that the following operations are possible
// cout << a and  cin >> a
// make sure they can be chained

int FastFib(int n);//implement the Fast Fibonacci function


int main()
{

    return 0;
}