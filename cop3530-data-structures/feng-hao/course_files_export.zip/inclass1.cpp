// inclass1.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include<iostream>
using namespace std;


int _tmain(int argc, _TCHAR* argv[])
{
	int x =2, y=1;
	cout<< (x | y) <<endl;

	cout<< (1<<5) <<endl;
	x=37;
	cout<< (x>>1) <<endl;

	return 0;
}

