// inclass3.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include<iostream>
using namespace std;

class Point
{
public:
	int x,y;
	Point(){x=0;y=0;z=0;}
	friend Point operator+(const Point &a,const Point &b);
	Point operator+(const Point &b)
	{
		Point temp;
		cout<<"function inside"<<endl;
		temp.x = x + b.x;
		temp.y = y + b.y;
		temp.z = z + b.z;
		return temp;	 
	}
	void display(ostream & out)
	{
	   out<<x<<" " <<y<<" " <<z;
	}
private:
	int z;
};

Point operator+(const Point &a,const Point &b)
{
	Point z;
	cout<<"function outside"<<endl;
	z.x = a.x+ b.x;
	z.y = a.y + b.y;
	z.z = a.z + b.z;
	return z;
}

ostream & operator<<(ostream &out, Point &a)
{
	//out<<a.x<<" "<<a.y<< " "<<a.z; 
	//(1) friend, (2) use helper 
	a.display(out);
    return out;
}

int _tmain(int argc, _TCHAR* argv[])
{
	Point a,b;
	a+b;
	a.operator+(b);
	cout<<a<<" "<<b;
	return 0;
}

