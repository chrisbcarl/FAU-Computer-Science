#include <iostream>

int namespace1()
{
	std::cout << "Hello, world!" << std::endl;
	return 0;
}