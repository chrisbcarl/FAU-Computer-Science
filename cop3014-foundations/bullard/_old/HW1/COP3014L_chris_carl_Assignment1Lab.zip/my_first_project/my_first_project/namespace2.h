using namespace std;

#include <iostream>

int namespace2()
{
	cout << "Hello, world!" << endl;
	return 0;
}