//Name: Christopher Carl
//Course: Foundations of Computer Science Laboratory
//Date: 16.05.21
//Time: 
//Teaching Assistant (TA):
//Description:	This is my first C++ program. It will be used to 
//				demonstrate my ability to create a C++ program and 
//				add an empty source file to the program named 
//				"my_first_program.cpp"

// standard i/o library that must be included in all programs
#include <iostream>

//standard namespace that must be included in all programs
using namespace std;

//main function (program) - function to be executed by your 
//program. All programs have a main function
int my_first_project()
{
	cout << "This is my first C++ program." << endl;
	cout << endl << "It seems really easy to perform output." << endl;
	cout << "I am so happy to be in this laboratory." << endl;
	cout << "I know I will be successful if I come to all laboratories " << endl
		 << "on time, complete each experiment, practice writing cod and program, " << endl
		 << "participate in class discussions, and study for quizzes and test." << endl;
	cout << endl;

	return 0;
}

